#!/usr/bin/env python3
"""Create three synthetic website drafts using an already installed Reprise.

Python standard library only. The destination must not exist. This script saves
versions, but never restores, deletes, starts a service, or touches real projects.
"""
import argparse
import hashlib
import html
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys


DRAFTS = (
    ('初稿', 'First draft', 'Keep the first idea.', '#fbf3e8', '#a34030', '50%'),
    ('第二稿', 'Second draft', 'Make the direction clear.', '#eef4ff', '#285fc9', '24px'),
    ('当前稿', 'Current draft', 'Keep every step in view.', '#edf5ec', '#33754b', '90px 20px'),
)


def page(title, headline, paper, accent, radius):
    return ('''<!doctype html><html lang="en"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Reprise recovery sample — ''' + html.escape(title) + '''</title>
<style>*{box-sizing:border-box}body{margin:0;background:''' + paper + ''';color:#172b24;
font-family:system-ui,sans-serif}main{max-width:1100px;margin:auto;padding:60px}
header{display:flex;justify-content:space-between;font-size:16px}section{display:grid;
grid-template-columns:1.5fr 1fr;align-items:center;gap:40px;min-height:460px}
h1{font-size:72px;line-height:1.05;letter-spacing:-.055em;margin:24px 0}
p{font-size:19px;line-height:1.7;max-width:520px}.shape{height:270px;background:''' + accent + ''';
border-radius:''' + radius + ''';display:grid;place-items:center;color:white;font-size:28px}
footer{font-size:15px}@media(max-width:650px){main{padding:28px}section{grid-template-columns:1fr;
padding:30px 0}h1{font-size:48px}.shape{height:180px}}</style>
<main><header><strong>Website recovery sample</strong><span>''' + html.escape(title) + '''</span></header>
<section><div><h1>''' + html.escape(headline) + '''</h1><p>This synthetic website has three saved drafts.
Find the first one, compare its files, and recover index.html into a new folder.</p></div>
<div class="shape">''' + html.escape(title) + '''</div></section>
<footer>Reprise tutorial sample. No personal data or external assets.</footer></main></html>\n''').encode('utf-8')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def prepare(destination, entry=None, cli=None):
    destination = Path(destination).expanduser().resolve()
    if destination.exists():
        raise ValueError('Destination already exists. Choose a new path; existing files are retained.')
    command = [str(Path(cli).expanduser().resolve())] if cli else [sys.executable, str(Path(entry).expanduser().resolve())]
    if not Path(command[-1]).is_file():
        raise ValueError('Installed Reprise entry was not found: ' + command[-1])
    destination.mkdir(parents=True)
    source, data = destination / 'source', destination / 'data'
    expected = destination / 'expected'
    source.mkdir(); expected.mkdir(); (destination / 'commands').mkdir()
    versions = []
    env = dict(os.environ)
    env.pop('PYTHONPATH', None)
    env.pop('PYTHONHOME', None)
    for number, (zh, en, headline, paper, accent, radius) in enumerate(DRAFTS, 1):
        content = page(en, headline, paper, accent, radius)
        (source / 'index.html').write_bytes(content)
        (source / 'notes.txt').write_text(en + '\n' + headline + '\n', encoding='utf-8')
        (expected / ('draft-%s.html' % number)).write_bytes(content)
        argv = command + ['--data', str(data), 'save', str(source), '--name', 'Website recovery demo', '--title', zh]
        result = subprocess.run(argv, cwd=str(destination), env=env, capture_output=True, text=True, timeout=120)
        record = dict(argv=argv, returncode=result.returncode, stdout=result.stdout, stderr=result.stderr)
        (destination / 'commands' / ('save-%s.json' % number)).write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
        if result.returncode:
            raise RuntimeError('Reprise save failed; retained logs: ' + str(destination / 'commands'))
        saved = json.loads(result.stdout)
        versions.append(dict(title=zh, title_en=en, sha=saved['result']['sha'], index_sha256=digest(source / 'index.html')))
        project = saved['project_id']
    if (source / '.git').exists():
        raise RuntimeError('Unexpected Git metadata in the source folder')
    summary = dict(schema=1, status='prepared', sample_only=True, project_id=project,
                   source=str(source), data=str(data), versions=versions,
                   source_current_sha256=digest(source / 'index.html'),
                   open_command=shlex.join(command + ['--data', str(data), 'open', str(source), '--folder', '--no-browser']),
                   restore_target=str(destination / 'restored-first-draft'),
                   restore_command=shlex.join(command + ['--data', str(data), 'restore', project, '--sha', versions[0]['sha'], '--path', 'index.html', '--to', str(destination / 'restored-first-draft')]),
                   source_git_initialized=False, restore_executed=False, deletion_executed=False)
    (destination / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--to', required=True, help='New directory for synthetic source, saved versions, and logs')
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--entry', help='Extracted Skill: reprise/scripts/reprise.py')
    group.add_argument('--cli', help='Installed reprise executable, for example a venv bin/reprise')
    args = parser.parse_args()
    try:
        prepare(args.to, args.entry, args.cli)
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
        parser.exit(1, str(error) + '\n')


if __name__ == '__main__':
    main()
