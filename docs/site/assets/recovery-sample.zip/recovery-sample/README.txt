Synthetic Reprise recovery tutorial sample.
Run python3 prepare.py --help. Requires an extracted Reprise Skill or installed CLI.
Destination must not exist. Saves three drafts; does not restore or delete.
